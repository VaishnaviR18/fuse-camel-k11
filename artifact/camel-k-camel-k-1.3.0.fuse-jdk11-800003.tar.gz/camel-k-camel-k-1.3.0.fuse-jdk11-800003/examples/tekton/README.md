# Example: Camel K in Tekton Pipelines

This example is part of a tutorial about running Camel K on Tekton pipelines.

You can find the tutorial at https://camel.apache.org/camel-k/latest/tutorials/tekton/tekton.html
