# Camel K Examples

This folder contains examples of Camel K integrations defined in various languages.